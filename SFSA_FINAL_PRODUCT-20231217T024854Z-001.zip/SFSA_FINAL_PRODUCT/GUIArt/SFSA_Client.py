from operator import index
from pathlib import Path
import socket
from time import sleep
import Accounts
import sys
import errno
import random
from random import seed
import string
import tkinterWarningInstance
import pickle
import select
import csv
import FileManager
import pandas as pd

# CONSTANTS

IP = "10.0.2.15"
PORT = 1234
ADDR = (IP,PORT)
SIZE = 1024
FORMAT = "utf-8"
HEADER_LENGTH = 20
DISCONNECT_MSG = "!DISCONNECT"


#HEADER TYPES
#Headers attacthed to the beginning of the message to be handled by the client
H_SIGN_UP = "SIGNUP"
H_LOGIN = "LOGINX"

#seed for random user id generation

# Create Queue of messages


byte_type = ""
queue = []

#byte type

def setByteType(m_type):
    global byte_type
    byte_type = m_type

def getByteType():
    return byte_type

# add strings to queue to send over
def addMessagetoQ(message):
   queue.append(message)

# remove message from queue to send over to server
def removeMessageFromQ(q,i):
   q.pop(i)

# generate Client ID
# Identifies the client as a 4 Digit 2 Letter combonation
# Example is 1234AA is one user id
# This user id is going to be stored in a dictonary and the ip and socket the client sends will get the user id
def generateClientID():
    
    #get all ascii letters
    lower_upper_alphabet = string.ascii_letters

    # Generate random int values
    value1 = random.randint(0,9)
    value2 = random.randint(0,9)
    value3 = random.randint(0,9)
    value4 = random.randint(0,9)
    letter1 = random.choice(lower_upper_alphabet)
    letter2 = random.choice(lower_upper_alphabet)
    #concatinated results
    clientID = str(value1) + str(value2) + str(value3) + str(value4) + letter1 + letter2
    print(clientID)
    return clientID

#function that receives messages from host

def receive_message_from_host(client_socket):
    try:
        #get the header of the message
        message_header = client_socket.recv(HEADER_LENGTH)

        print("Mess Header: ", int(message_header.decode("utf-8")))

        if not len(message_header):
            print("not header")
            return False

        #get type of data

        m_type = client_socket.recv(6)

        if not len(m_type):
            print("not m_type")
            return False

        #strip message header
        message_length = int(message_header.decode("utf-8").strip())

        return {"header": message_header, "m_type":m_type, "data": client_socket.recv(message_length)}
        
    except:
        return False

def main():

   # generate clientID
   my_clientID = generateClientID()
   #generate type
   my_type = "CONNCT"

   # Create Socket
   # Create a socket
   # socket.AF_INET - address family, IPv4, some otehr possible are AF_INET6, AF_BLUETOOTH, AF_UNIX
   # socket.SOCK_STREAM - TCP, conection-based, socket.SOCK_DGRAM - UDP, connectionless, datagrams, socket.SOCK_RAW - raw IP packets
   client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

   # Connect to a given ip and port
   client_socket.connect((IP, PORT))

   # Set connection to non-blocking state, so .recv() call won;t block, just return some exception we'll handle
   client_socket.setblocking(False)

   sockets_list = [client_socket]
   # send ClientID to Server
   clientID = my_clientID.encode('utf-8')
   m_type  = my_type.encode('utf-8')
   client_header = f"{len(clientID):<{HEADER_LENGTH}}".encode('utf-8')
   client_socket.send(client_header + m_type + clientID)
   message = ""
   while True:

   # Wait for queue to be > 0 
    m_type = "TEST"

    if queue:
        for i in range(len(queue)):
            # set message to first item in queue
            #print("message type is ", type(message))
            #print("message type is ",type(message) == str)
            
            if len(queue) == 1:
               i = 0
            
            #print("I is ", i )
            if type(queue[i]) == str:
                message = bytes(queue[i],'utf-8')
            
            # If message is not empty - send it and type of string
            if message and type(queue[i]) == str:


                #Get Type Of message to send to client
                messageType = message.split()

                #check to see if we have extra data after split
                #for sign in and create account choices
                if len(messageType) > 1:

                    
                    message = messageType[1].strip()
                    m_type = messageType[0].strip().decode('utf-8')


                #else it is a pull request from the server
                #no extra data from split

                print("TYPE IS ", m_type)

                if m_type == "SHARED":
                    print("Getting Shared Files")

                #if we are requesting to download a file that is shared with us privately
                if m_type == "SELFDX":
                    print("sending selfdx message")

                    
                #if we are creating a account
                if m_type == "SIGNUP":
                    message  = messageType[1].strip().decode('utf-8') + " " + messageType[2].strip().decode('utf-8')
                    message  = message.encode('utf-8')

                #if client wants to login
                if m_type == "LOGINX":

                    message  = messageType[1].strip().decode('utf-8') + " " + messageType[2].strip().decode('utf-8')
                    message  = message.encode('utf-8')
                # Encode message to bytes, prepare header and convert to bytes, 
                en_type = bytes(m_type,'utf-8')
                print(len(m_type))

                message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')
                client_socket.send(message_header + en_type + message)

                #remove the message from the queue
                if queue:
                    removeMessageFromQ(queue,i)
                #print("PASS: %i\n",i)

            #if message is not empty and type of bytes we are using pickle so we cant concatnate with strings
            if queue:
                if message and type(queue[i]) == bytes:
                    # this tells the server we are sending bytes

                    message = queue[i]
                    
                    bt_type = getByteType()

                    if bt_type == "UPLOAD_SYM_KEY":

                        m_type = "SYMKEY"

                        en_type = bytes(m_type,'utf-8')
                        print(len(m_type))

                        message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')

                        client_socket.send(bytes(message_header) + bytes(en_type) + message)


                    if bt_type == "APPEND_USER_DOWNLOAD":

                        m_type = "BYTESX"

                        en_type = bytes(m_type,'utf-8')
                        print(len(m_type))

                        message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')

                        client_socket.send(bytes(message_header) + bytes(en_type) + message)

                    if bt_type == "REQUEST_SYMKEY":
                   
                        m_type = "RESYMX"

                        en_type = bytes(m_type,'utf-8')
                        print(len(m_type))

                        message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')

                        client_socket.send(bytes(message_header) + bytes(en_type) + message)

                    if queue:
                        removeMessageFromQ(queue,i)
    try:
        # Now we want to loop over received messages (there might be more than one) and print them
        while True:


            #call select 
            
            

            # Receive our "header" containing username length, it's size is defined and constant
            message_header = client_socket.recv(HEADER_LENGTH)

            #print(message_header.decode('utf-8'))

            # If we received no data, server gracefully closed a connection, for example using socket.close() or socket.shutdown(socket.SHUT_RDWR)
            if not len(message_header):
                print('Connection closed by the server')
                sys.exit()


            message_type = client_socket.recv(6).decode('utf-8')


             # If we received no data, server gracefully closed a connection, for example using socket.close() or socket.shutdown(socket.SHUT_RDWR)
            if not len(message_type):
                print('Connection closed by the server')
                sys.exit()

            # Convert header to int value
            message_length = int(message_header.decode('utf-8').strip())

            if message_type == "SIGNUP" or message_type == "LOGINX":

                message = client_socket.recv(message_length).decode('utf-8')
            

            #interact with GUI

            #SIGNUP CASES
            if(message == "AVAILABLE"):
                tkinterWarningInstance.accountMessages(message)
            elif(message == "TAKEN"):
                tkinterWarningInstance.accountMessages(message)

            #LOGIN CASES

            if(message == "GOOD_LOGIN"):
                #print("GOOD")
                #print("message:",message, " ", message_length)
                tkinterWarningInstance.switchScreen(message)

            elif(message == "BAD_LOGIN"):
                tkinterWarningInstance.badLogin()

            
            
            # MY FILES CASES


            #Print message
            #print(f'{message}')
            
            

            #unpickle any files we receive

            if message_type == "SELFDX":
                message = client_socket.recv(2048)

                rows_unpickled = pickle.loads(message)

                path = "SFSA_ACC/"
                username = FileManager.getCurrentUser()
                path = Path(path+username+".csv")

                with open(path,'w',newline='') as csvfile:

                    csvwriter = csv.writer(csvfile)

                    for row in rows_unpickled:


                        csvwriter.writerow(row)

                    csvfile.close()
                #print("Rows unpickled is ", rows_unpickled)

            if message_type == "SHARED":
                message = client_socket.recv(2048)

                rows_unpickled = pickle.loads(message)

                path = "SFSA_ACC/"
                username = FileManager.getCurrentUser()
                path = Path(path+username+".csv")

                with open(path,'w',newline='') as csvfile1:
                    csvwriter = csv.writer(csvfile1)
                    for row in rows_unpickled:
                        csvwriter.writerow(row)
                    csvfile1.close()


                #filter out csv with only different group names
                df = pd.read_csv(f"SFSA_ACC/{username}.csv")
                differntGroupDF = df.loc[ (df['group'] != "self") ]
                differntGroupDF.to_csv(path, index=False)

                #print("Rows unpickled is ", rows_unpickled)
            if message_type == "KEYSXX":
                
                message = client_socket.recv(4096)

                keys_unpickled = pickle.loads(message)

                username = FileManager.getCurrentUser()
                #place keys
                FileManager.placeKeys(username,keys_unpickled)

                
            #download symetric key    
            if message_type == "RESYMX":
                message = client_socket.recv(2048)

                sym_unpickled = pickle.loads(message)

                filename = sym_unpickled[0]

                sym_key_bytes = sym_unpickled[1]

                path = "SFSA_ACC/"
                
                username = FileManager.getCurrentUser()
                
                path = f"{path}{username}/encryptedKeyStore/"

                #create symkey
                with open(path+f"{filename}encrypted.key","wb") as f:
                    f.write(sym_key_bytes)
                    f.close()
                    
            # MY FILES CASES


            #Print message
            #print(f'{message}')

    except IOError as e:
        # This is normal on non blocking connections - when there are no incoming data error is going to be raised
        # Some operating systems will indicate that using AGAIN, and some using WOULDBLOCK error code
        # We are going to check for both - if one of them - that's expected, means no incoming data, continue as normal
        # If we got different error code - something happened
        if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
            print('Reading error: {}'.format(str(e)))
            sys.exit()

        # We just did not receive anything
        continue

    #except Exception as e:
    #    # Any other exception - something happened, exit
    #    print('Reading error Exception: '.format(str(e)))
    #    sys.exit()



if __name__ == "__main__":
    main()