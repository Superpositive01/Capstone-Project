# This file contains all layouts for SFSA GUI
# Preston Robbins
# JAN 13 2022

# Multi-frame tkinter application v2.3
from cProfile import label
from email import message
from email.headerregistry import Group
from fileinput import filename
#from msilib.schema import File
from pathlib import Path
import tkinter as tk
from tkinter.constants import SEL_FIRST, W
from tkinter.tix import Tree
from tokenize import group
from typing import Container
from PIL import Image, ImageTk
from tkinter import Menu, ttk
from tkinter import filedialog
from tkinter import messagebox
import threading

from numpy import gradient
from requests import options
from AccountSystem import *
import Accounts
import SFSA_Client
import time
import FileManager
import GroupManager
import csv

class SFSA(tk.Tk):
   

    #initialization function for frames
    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self,*args,**kwargs)
        
        # set teh container to tk.Frame
        container = tk.Frame(self)

        #pack
        container.pack(side="top",fill="both",expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0,weight=1)

       
        screens = [WelcomeScreen,LoginScreen,CreateAccountScreen, MainMenu]

        #dictonary of frames
        self.frames = {}

        for F,geometry in zip ((WelcomeScreen,LoginScreen,CreateAccountScreen, MainMenu), ('1850x554','1280x1080','1280x1080','1280x1080')):

            # set frame to start page upon initalization 
            frame = F(container,self)

            # set current frame to StartPage
            self.frames[F] = (frame,geometry)


            frame.grid(row=0, column=0, sticky="nsew")        
        
        SFSA.showMenuBar(self,container)
            
        # show the frame
        self.show_frame(WelcomeScreen)
        self.bind('<Button-1>', SFSA.display_coordinates)

    #print x y coordiantes upon button press
    def display_coordinates(event):
            print(f'x={event.x} y={event.y}')

    # function to show frame
    def show_frame(self,cont):
        frame,geometry = self.frames[cont]
        self.geometry(geometry)
        frame.tkraise()

    # function to create menu bar that shows options
    def showMenuBar(self,container):       
        # Create a menubar with options such as 'Account' -> 'LOGOUT'

        menuBar = tk.Menu(container)
        fileMenu =  tk.Menu(menuBar, tearoff=0)
        
         #Add logout button under Account in menu 
        fileMenu.add_command(label="Logout",command=SFSA.confirmLogoutPopup)
        menuBar.add_cascade(label="Account", menu=fileMenu)

        #configure self to have these options
        tk.Tk.config(self,menu=menuBar)  

    def confirmLogoutPopup():
        
        messagebox.askyesno('Yes|No', 'Do you want to logout?')

        
class WelcomeScreen(tk.Frame):
        def __init__(self,parent,controller):

            tk.Frame.__init__(self,parent)

            # set the window size for the screen
            canvas = tk.Canvas(self, width=1850, height=554)
            
            # use the 3 column grid
            canvas.grid(columnspan=3)
            
          
            #open image using PIL library
            logo = Image.open('loginscreen.png')

            #convert image to a usable tkinter library 
            logo = ImageTk.PhotoImage(logo)

            # Set image in canvas
            canvas.create_image(0,0, image=logo, anchor="nw")

            canvas.create_image = logo


         
            # Login Button 
            login_btn = tk.Button(self, text="LOGIN", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17, command=lambda:controller.show_frame(LoginScreen))
            
            login_btn_window = canvas.create_window(947,403, anchor="sw", window=login_btn)
            
            create_acc_btn = tk.Button(self, text="CREATE ACCOUNT", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17, command=lambda:controller.show_frame(CreateAccountScreen))
            
            create_acc_window = canvas.create_window(947,508, anchor="sw", window=create_acc_btn)
       
class LoginScreen(tk.Frame):

    #variable to when to switch to main menu frame if valid login
    switchFrame = False
 
    #send login info to server
    def sendLoginInfo(username,password):
            message = username + " " + password
            FileManager.setCurrentUser(username)
            SFSA_Client.addMessagetoQ("LOGINX " + message)
   
   #function to switch frames to main app
    def showMainMenu(self, controller, username, password):

        username = username.strip()
        LoginScreen.sendLoginInfo(username,password)

        time.sleep(5)
        if LoginScreen.switchFrame == True:
            FileManager.setCurrentUser(username)
            controller.show_frame(MainMenu)
            LoginScreen.switchFrame = False

            # check for local file storage for this account
           
            FileManager.createUserNameFile(username)
            FileManager.createKeys(username)
            GroupManager.createGroupFolder(username)
            


    def __init__(self,parent,controller):

            tk.Frame.__init__(self,parent)

            #function that sends in all the infomration in the fields as a message


            # Create a 3x3 grid to place our packed layout in

            self.grid_columnconfigure(0, weight=1)
            self.grid_columnconfigure(1, weight=1)
            self.grid_columnconfigure(2, weight=1)

            self.grid_rowconfigure(0,weight=1)
            self.grid_rowconfigure(1,weight=1)
            self.grid_rowconfigure(2,weight=1)
            self.grid_rowconfigure(3,weight=1)

            #master frame that we place in the grid we created for this frame
            frame = tk.Frame(self)
            frame.grid(column=1,row=2)

            #frames to have icon and entry in the same area

            #contains userIcon and entry
            userEntryFrame= tk.Frame(frame)
            #contrains passwordIco and Entry
            passwordEntryFrame=tk.Frame(frame)

            #contains back and login buttons
            buttonsFrame = tk.Frame(frame)           
            # Get login icons for screen
            userIcon = Image.open("user_Icon.png")
            passwordIcon= Image.open("lock_Icon.png")

            #SFSA Logo
            sfsa_logo = Image.open("SFSALOGO2.png")

            #convert icons to tkinter widget
            userI_tk = ImageTk.PhotoImage(userIcon)
            passI_tk = ImageTk.PhotoImage(passwordIcon)

            sfsa_logo = ImageTk.PhotoImage(sfsa_logo)

            #create labels for image
            userIconLabel = tk.Label(userEntryFrame,image=userI_tk)
            passIconLabel = tk.Label(passwordEntryFrame,image=passI_tk)

            sfsa_logoLabel = tk.Label(frame,image=sfsa_logo)

            userIconLabel.image = userI_tk
            passIconLabel.image = passI_tk
            sfsa_logoLabel.image = sfsa_logo

            # Username label 
            usernameLabel = tk.Label(frame, text="Username", font=("Arial",15))

           

            # Username entry
            usernameEntry = tk.Entry(userEntryFrame)

            
            # Password label
            passwordLabel = tk.Label(frame, text="Password",font=("Arial",15))


            # Password entry
            passwordEntry = tk.Entry(passwordEntryFrame)


             #Login Button 
            login_btn = tk.Button(buttonsFrame, text="LOGIN", bg="#20bebe",  fg="white", anchor='center', height=2, width=20, command=lambda:LoginScreen.showMainMenu(self,controller,usernameEntry.get(),passwordEntry.get()))
            #login_btn = tk.Button(buttonsFrame, text="LOGIN", bg="#20bebe",  fg="white", anchor='center', height=2, width=20, command=lambda:controller.show_frame(MainMenu))

            back_btn = tk.Button(buttonsFrame, text="BACK", bg="#20bebe",  fg="white", anchor='center', height=2, width=20, command=lambda:controller.show_frame(WelcomeScreen))
  



            # Pack Logo
            sfsa_logoLabel.pack()

            #use pack to put in frame within master grid

            #pack label in frame
            usernameLabel.pack(ipadx=50, ipady=50)
            #pack Entry frame with userIconLabel and UserEntry
            userEntryFrame.pack()
            
            #pack userLabel and usernameEntry in Frame
            userIconLabel.pack(side=tk.LEFT)
            usernameEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)

            #password label in sub frame
            passwordLabel.pack(side=tk.TOP,ipadx=50, ipady=50)

            #pack entry fraem with passwordicon and password entry
            passwordEntryFrame.pack()

            #pack widgets in passwordframe
            passIconLabel.pack(side=tk.LEFT, padx=10)
            passwordEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)

            #pack budget frame in subframe
            buttonsFrame.pack()

            back_btn.pack(side=tk.LEFT, ipady=10, pady=20,padx=2)
            login_btn.pack(side=tk.LEFT, ipady=10, pady=20,padx=2)
         
            
           
       
class CreateAccountScreen(tk.Frame):


    #netsed function that checks requirements for account creation
    # takes in username confirmusername password confirmpassword 
    def checkRequirments(un,c_un,pw,c_pw):

        if(checkNameRequirments(un) == False):

            messagebox.showerror(message="Username Requirements not meet!")

        elif(checkPasswordRequirement(pw) == False):
            
            messagebox.showerror(message="Password Requirements not meet!")

        elif(confirmEqual(un,c_un) == False):

            messagebox.showerror(message="Usernames do not match!")

        elif(confirmEqual(pw,c_pw) == False):
            
            messagebox.showerror(message="Passwords do not match!")

        else:
                #Create Account with UserName and Password
                newAcc = Accounts.Account
                newAcc.setUserName(newAcc,un)
                newAcc.setPassword(newAcc,pw)
                #print(newAcc.getUserName(newAcc))

                #Appened it to Client Roster
                username = newAcc.getUserName(newAcc)
                password = newAcc.getPassword(newAcc)
                message = username + " " + password
                SFSA_Client.addMessagetoQ("SIGNUP " + message)
                
            
    def __init__(self,parent,controller):

        tk.Frame.__init__(self,parent)

        #set the weights of the columns and rows 
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=3)
        self.grid_columnconfigure(2, weight=1)

        self.grid_rowconfigure(0,weight=1)
        self.grid_rowconfigure(1,weight=1)
        self.grid_rowconfigure(2,weight=1)
        self.grid_rowconfigure(3,weight=1)
        
        frame = tk.Frame(self)
        frame.grid(column=1, row=2)

       

         #contains userIcon and entry
        userEntryFrame= tk.Frame(frame)

         #contains userIcon and Confirm entry
        userEntryConfirmFrame= tk.Frame(frame)
        
        #contrains passwordIco and Entry
        passwordEntryFrame=tk.Frame(frame)

        #contarins passwordIco and Password confirm entry
        passwordConfirmFrame= tk.Frame(frame)

        #contains back and create account buttons
        buttonsFrame = tk.Frame(frame)           
        
        # Get login icons for screen
        userIcon = Image.open("user_Icon.png")
        passwordIcon= Image.open("lock_Icon.png")
        
        keyImage = Image.open("key.png")
        #SFSA Logo
        sfsa_logo = Image.open("SFSALOGO.png")

        sfsa_logo = ImageTk.PhotoImage(sfsa_logo)

        #convert icons to tkinter widget
        userI_tk = ImageTk.PhotoImage(userIcon)
        passI_tk = ImageTk.PhotoImage(passwordIcon)
        keyI_tk = ImageTk.PhotoImage(keyImage)


        #create labels for image
        userIconLabel = tk.Label(userEntryFrame,image=userI_tk)
        passIconLabel = tk.Label(passwordEntryFrame,image=passI_tk)
        sfsa_logoLabel = tk.Label(frame,image=sfsa_logo)

        sfsa_logoLabel.image = sfsa_logo

        userIconLabel.image = userI_tk
        passIconLabel.image = passI_tk


        keyImageUserName = tk.Label(userEntryConfirmFrame,image=keyI_tk)
        keyImageUserName.image = keyI_tk

        keyImagePassword = tk.Label(userEntryConfirmFrame,image=keyI_tk)
        keyImagePassword.image = keyI_tk
        
        keyImagePasswordConfirm = tk.Label(passwordConfirmFrame,image=keyI_tk)
        keyImagePasswordConfirm.image = keyI_tk
        
        #Username
        userNameLabel= tk.Label(frame, text="Username",font=("Arial",15))

        #Username entry
        userNameEntry= tk.Entry(userEntryFrame)

        #Confirm UserName
        confirmUserNameLabel = tk.Label(frame, text="Confirm Username",font=("Arial",15))

        #Confirm UserName Entry

        confirmUserNameEntry = tk.Entry(userEntryConfirmFrame)

        #Password
        passwordLabel= tk.Label(frame,text="Password", font=("Arial",15))
        
        #Password entry
        passwordEntry= tk.Entry(passwordEntryFrame)

        #Confirm Password
        confrmPasswordLabel= tk.Label(frame,text="Confirm Password",font=("Arial",15))

        #Confirm Password entry
        confirmPasswordEntry= tk.Entry(passwordConfirmFrame)

        #Create Account Button
        create_acc_btn = tk.Button(buttonsFrame, text="CREATE ACCOUNT", bg="#20bebe",  fg="white", anchor='center', height=2, width=20, 
                        command=lambda:CreateAccountScreen.checkRequirments(userNameEntry.get(),
                                                                        confirmUserNameEntry.get(),
                                                                        passwordEntry.get(),
                                                                        confirmPasswordEntry.get()))

        #Back Button
        back_btn = tk.Button(buttonsFrame, text="BACK",  bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=lambda:controller.show_frame(WelcomeScreen))



        #Logo
        sfsa_logoLabel.pack()

        #pack contents into frame
        userNameLabel.pack(ipadx=50, ipady=50)
        
        #userEntryFrame 
        userEntryFrame.pack()

        userIconLabel.pack(side=tk.LEFT)
        userNameEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)


        #confirm UserName
        confirmUserNameLabel.pack(ipadx=50, ipady=50)
        userEntryConfirmFrame.pack()

        keyImageUserName.pack(side=tk.LEFT)
        confirmUserNameEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)


        #passwordFrame
        passwordLabel.pack(ipadx=50, ipady=50)
        passwordEntryFrame.pack()

        passIconLabel.pack(side=tk.LEFT)
        passwordEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)

        #confirm password frame
        confrmPasswordLabel.pack(ipadx=50, ipady=50)

        passwordConfirmFrame.pack()
        keyImagePasswordConfirm.pack(side=tk.LEFT)
        confirmPasswordEntry.pack(side=tk.LEFT,ipadx=10, ipady=10)

        #buttons frame
        buttonsFrame.pack()
        back_btn.pack(side=tk.LEFT,ipady=10, pady=20,padx=2)
        create_acc_btn.pack(side=tk.LEFT,ipady=10, pady=20,padx=2)


class MainMenu(tk.Frame):

    
# ** MY FILES POPUP SCREENS *********************************************************************************


    def downloadFileSelf(values):

        currentUser = FileManager.getCurrentUser()
        
        #get values from array
        filename = values[0].strip()
        date = values[1].strip()
        u_time = values[2].strip()
        username = values[3].strip()
        group = 'self'

        #get symetric key from server
        FileManager.sendMsgTogetSymetricKey(username,filename)

        time.sleep(10)

        FileManager.getHashFromCSV(currentUser,filename,date,u_time,group)

    def downloadFilesShared(values):
        currentUser = FileManager.getCurrentUser()
        
        #get values from array
        filename = values[0].strip()
        date = values[1].strip()
        u_time = values[2].strip()
        username = values[3].strip()
        group = 'other'

        #get symetric key from server
        FileManager.sendMsgTogetSymetricKey(username,filename)

        time.sleep(10)

        FileManager.getHashFromCSV(currentUser,filename,date,u_time,group)
        
    #creates a popup window for confirming file downlaod
    def confirmDownloadWindow(values):
        #create tkinter top level view of window
        confirmDownloadWindow = tk.Toplevel()

        #create label that shows file info
        labelText = f"{values[0]} {values[1]} {values[2]} {values[3]}" 

        #label to confirm selected file
        fileInfoLabel = tk.Label(confirmDownloadWindow, text=labelText, font=("Arial",15))

        #button for downloading files
        button = tk.Button(confirmDownloadWindow,text="DOWNLOAD" , anchor='center', height=2, width=20, command=lambda:MainMenu.downloadFileSelf(values))

        fileInfoLabel.pack()

        button.pack()

    #creates a popup window for confirming file downlaod
    def confirmDownloadWindowShared(values):
        #create tkinter top level view of window
        confirmDownloadWindow = tk.Toplevel()

        #create label that shows file info
        labelText = f"{values[0]} {values[1]} {values[2]} {values[3]}" 

        #label to confirm selected file
        fileInfoLabel = tk.Label(confirmDownloadWindow, text=labelText, font=("Arial",15))

        #button for downloading files
        button = tk.Button(confirmDownloadWindow,text="DOWNLOAD" , anchor='center', height=2, width=20, command=lambda:MainMenu.downloadFileSelf(values))

        fileInfoLabel.pack()

        button.pack()


    #get current item of file viewer after downlaod    
    def onDoubleClick(a):

        currentItem = a.focus()

        currentItemArray = a.item(currentItem)

        #get values of array 
        fileValues = currentItemArray['values']

        #create popup screen confirming the user wants to download selected file

        MainMenu.confirmDownloadWindow(fileValues)


    def onDoubleClickShared(a):

        currentItem = a.focus()

        currentItemArray = a.item(currentItem)

        #get values of array 
        fileValues = currentItemArray['values']

        #create popup screen confirming the user wants to download selected file

        MainMenu.confirmDownloadWindowShared(fileValues)   


    # Pop up window for myFiles section button when pressed
    def myFilesScreen():

        #send message to SFSA CLIENT to tell use we need to pull csv from server
        
        #message for SELFDX
        message = FileManager.getCurrentUser()

        #send ti to messageQ
        SFSA_Client.addMessagetoQ("SELFDX " + message)


        #wait for row data to populate local csv

        time.sleep(5)
        myFilesWindow = tk.Toplevel()
        myFilesWindow.title('File Viewer')

        #define columns
        columns = ('n','d','t','u')
        
        #make a treeview
        myFilesTree = ttk.Treeview(myFilesWindow, columns=columns, show='headings')
        
        #define headings
        myFilesTree.heading('n',text='Name')
        myFilesTree.heading('d',text='Date')
        myFilesTree.heading('t',text='Time')
        myFilesTree.heading('u',text='User')
        
        path = "SFSA_ACC/"
        username = FileManager.getCurrentUser()
        path = Path(path+username+".csv")

        with open(path) as f:
            reader = csv.DictReader(f, delimiter=',')
            for row in reader:
                name = row['filename']
                date = row['date']
                u_time = row['time']
                user = row['name']
                myFilesTree.insert("", 0, values=(name, date, u_time,user))
            f.close()

        #bind double click to tree
        myFilesTree.bind("<Double-1>", lambda event, a=myFilesTree: MainMenu.onDoubleClick(a))
        #pack tree
        myFilesTree.pack()

    #function to pull all shared files
    def sharedFilesScreen():
        #send message to SFSA CLIENT to tell use we need to pull csv from server
        
        #message for SELFDX
        message = FileManager.getCurrentUser()

        #send ti to messageQ
        SFSA_Client.addMessagetoQ("SHARED " + message)


        #wait for row data to populate local csv

        time.sleep(5)
        myFilesWindow = tk.Toplevel()
        myFilesWindow.title('File Viewer')

        #define columns
        columns = ('n','d','t','u')
        
        #make a treeview
        myFilesTree = ttk.Treeview(myFilesWindow, columns=columns, show='headings')
        
        #define headings
        myFilesTree.heading('n',text='Name')
        myFilesTree.heading('d',text='Date')
        myFilesTree.heading('t',text='Time')
        myFilesTree.heading('u',text='User')
        
        path = "SFSA_ACC/"
        username = FileManager.getCurrentUser()
        path = Path(path+username+".csv")

        with open(path) as f:
            reader = csv.DictReader(f, delimiter=',')
            for row in reader:
                name = row['filename']
                date = row['date']
                u_time = row['time']
                user = row['name']
                myFilesTree.insert("", 0, values=(name, date, u_time,user))
            f.close()

        #bind double click to tree
        myFilesTree.bind("<Double-1>", lambda event, a=myFilesTree: MainMenu.onDoubleClickShared(a))
        #pack tree
        myFilesTree.pack()
# ************* GROUPS POP UP SCREENS **********************************************************************

    def displayGroups(tree):
       
        username = FileManager.getCurrentUser()
        path = Path(f"SFSA_ACC/{username}/Groups/masterfile.csv")
        with open(path) as f:
            reader = csv.DictReader(f, delimiter=',')
            for row in reader:
                name = row['name']
                date = row['date']
                u_time = row['time']
                host = row['host']
                tree.insert("", 0, values=(name, date, u_time,host))
            f.close()

    # Pop up window for viewing groups
    def GroupsScreen():
        groupsWindow = tk.Toplevel()
        groupsWindow.title('View Groups')
        #define columns
        columns = ('n','d','t','h')
        
        #make a treeview
        groupsTree = ttk.Treeview(groupsWindow, columns=columns, show='headings')
        
        #define headings
        groupsTree.heading('n',text='Group Name')
        groupsTree.heading('d',text='Date Added')
        groupsTree.heading('t',text='Time Added')
        groupsTree.heading('h',text="Host")

        MainMenu.displayGroups(groupsTree)

        #pack tree
        groupsTree.pack()


    # Pop up window for group management 

    def manageGroupsScreen():

        groupsWindow = tk.Toplevel()
        groupsWindow.title('Manage Groups')

        # Create frame for window
        masterFrame = tk.Frame(groupsWindow)

        masterFrame.pack()

        # Create frame for Group Management

        groupFrame = tk.Frame(masterFrame)

        # Create frame for Group Managment buttons
        groupFrameButtons = tk.Frame(groupFrame)

        # Create frame for user Management 
        userFrame = tk.Frame(masterFrame)

        # Create frame for user Management Buttons
        userFrameButtons = tk.Frame(userFrame)


        #********************** GROUPS FRAME  ********************************************
        
        # Label for Group Frame
        groupLabel = tk.Label(masterFrame, text="Groups")
        #define columns
        group_columns = ('n','d','t','h')
        
        #make a treeview
        groupsTree = ttk.Treeview(groupFrame, columns=group_columns, show='headings')
        
        #define headings
        groupsTree.heading('n',text='Group Name')
        groupsTree.heading('d',text='Date Added')
        groupsTree.heading('t',text='Time Added')
        groupsTree.heading('h',text="Host")

        MainMenu.displayGroups(groupsTree)

        #buttons for group frame
        add_btn_group =   tk.Button(groupFrameButtons,text="ADD" , anchor='center', height=2, width=20, command=lambda:MainMenu.addGroupFrame(groupsTree))
        remove_btn_group =   tk.Button(groupFrameButtons,text="REMOVE", anchor='center', height=2, width=20, command=lambda:MainMenu.removeGroupFrame(groupsTree))

        groupsTree.bind("<Double-1>", lambda event, a=groupsTree: MainMenu.viewUsers(groupsTree,userTree))

         #pack tree
        groupLabel.pack()
        groupFrame.pack()
        groupsTree.pack(side=tk.LEFT)
        groupFrameButtons.pack(side=tk.LEFT)
        add_btn_group.pack()
        remove_btn_group.pack()

        # ******************** USER FRAME ***************************************************************
        
        # Label for Group Frame
        userLabel = tk.Label(masterFrame, text="Users")
        
        #define columns
        user_columns = ('u','d','t','h')
        
        #make a treeview
        userTree = ttk.Treeview(userFrame, columns=user_columns, show='headings')
        
        #define headings
        userTree.heading('u',text='User Name')
        userTree.heading('d',text='Date Added')
        userTree.heading('t',text='Time Added')
        userTree.heading('h',text="Host")

        #buttons for group frame
        add_btn_user =   tk.Button(userFrameButtons,text="ADD" , anchor='center', height=2, width=20, command=lambda:MainMenu.addUserFrame(groupsTree,userTree))
        remove_btn_user =   tk.Button(userFrameButtons,text="REMOVE", anchor='center', height=2, width=20, command=lambda:MainMenu.removeUserFrame(groupsTree,userTree))

        userLabel.pack()
        userFrame.pack()
        userTree.pack(side=tk.LEFT)
        userFrameButtons.pack(side=tk.LEFT)
        add_btn_user.pack()
        remove_btn_user.pack()

# ***************************** ADD and CREATE GROUP POP UPS ***************************************************************************************************************


    def getSelectedGroup(a):
        currentItem = a.focus()

        currentItemArray = a.item(currentItem)

        #get values of array 
        fileValues = currentItemArray['values']

        group = fileValues[0].strip()

        return group



    def addUserToGroup(frame, userTree,groupframe,userEntry):

        group = MainMenu.getSelectedGroup(groupframe)

        user = userEntry.get().strip()

        GroupManager.addUserToGroupFile(FileManager.getCurrentUser(), group,user)

        frame.destroy()

        MainMenu.displayUsers(userTree,group)

    def displayUsers(userTree,group):
       #cleartree
        for item in userTree.get_children():
            userTree.delete(item)

        username = FileManager.getCurrentUser()
        path = Path(f"SFSA_ACC/{username}/Groups/{group}.csv")
        with open(path) as f:
            reader = csv.DictReader(f, delimiter=',')
            for row in reader:
                name = row['user']
                date = row['date']
                u_time = row['time']
                host = row['host']
                userTree.insert("", 0, values=(name, date, u_time,host))
            f.close()

    def viewUsers(groupTree,userTree):
        group = MainMenu.getSelectedGroup(groupTree)
        #print("Group is ", group)
        MainMenu.displayUsers(userTree,group)


    
    #Add a user to group prompt
    def addUserFrame(groupsTree,userTree):
        addUserPrompt = tk.Toplevel()

        #create frame for label and buttons
        masterFrame = tk.Frame(addUserPrompt)
        buttonsFrame = tk.Frame(masterFrame)

        masterFrame.pack()

        #create label 
        entryLabel = tk.Label(masterFrame, text="Enter Username: ")

        # create entry
        userEntry = tk.Entry(masterFrame)

        #create add and cancel buttons
        addButton = tk.Button(buttonsFrame,text="ADD", height=2, width=20, command=lambda:MainMenu.addUserToGroup(addUserPrompt,userTree,groupsTree,userEntry))
        cancelButton= tk.Button(buttonsFrame, text= "CANCEL", height=2, width=20, command=lambda:MainMenu.cancelGroupButton(addUserPrompt))



        #pack 
        entryLabel.pack(pady=5)
        userEntry.pack(ipadx= 10, ipady=10, pady= 5)


        buttonsFrame.pack(pady=5 )

        cancelButton.pack(side=tk.LEFT)
        addButton.pack(side=tk.LEFT)

    #get selected User
    def getSelectedUser(userTree):
        currentItem = userTree.focus()

        currentItemArray = userTree.item(currentItem)

        #get values of array 
        fileValues = currentItemArray['values']

        user = fileValues[0].strip()

        return user

    #remove user
    def removeUserButton(window,groupTree,userTree):
        
        group = MainMenu.getSelectedGroup(groupTree)
        user = MainMenu.getSelectedUser(userTree)
        
        GroupManager.removeUserFromGroup(FileManager.getCurrentUser(),group,user)

        
        MainMenu.displayUsers(userTree,group)
        
        window.destroy()


    def removeUserFrame(groupTree,userTree):
        removeUserPrompt = tk.Toplevel()

        # Create frames and pack master for popup
        masterFrame = tk.Frame(removeUserPrompt)

        masterFrame.pack()

        # Create frame for button
        buttonsFrame = tk.Frame(masterFrame)
        
        #Create label for 'Are you sure?' prompt
        confirmLabel = tk.Label(masterFrame,text="Are you sure you want to delete this user? ", font=("Arial",15))

        #Create buttons 'YES' and 'NO' 

        yesButton =  tk.Button(buttonsFrame,text="YES", padx=5, height=2, width=20, command=lambda:MainMenu.removeUserButton(removeUserPrompt,groupTree,userTree))
        noButton  =  tk.Button(buttonsFrame, text="NO", padx= 5, height=2, width=20, command=lambda:MainMenu.cancelGroupButton(removeUserPrompt))

        # Pack contents 

        confirmLabel.pack()
        buttonsFrame.pack(pady=5)

        noButton.pack(side=tk.LEFT)
        yesButton.pack(side=tk.LEFT)



    #on double click group frame

    def removeGroupFromManager(window,a):

        currentItem = a.focus()

        currentItemArray = a.item(currentItem)


        if currentItemArray:
            #get values of array 
            groupValues = currentItemArray['values']

            print("current GROUP FRAME VALues are", groupValues)

        

            #remove from master file
            GroupManager.removeFromGroupMasterFile(FileManager.getCurrentUser,groupValues[0].strip(),groupValues[1].strip(),groupValues[2].strip(),groupValues[3].strip())

            #cleartree
            for item in a.get_children():
                a.delete(item)

            #display groups
            MainMenu.displayGroups(a)

            #destroy window
            window.destroy()

    #control for the gui and calls group manager function to add group 
    def addGroupButton(groupsTree,window,username,u_entry):
        #add text file
        GroupManager.addGroup(username,u_entry)
        #cleartree
        for item in groupsTree.get_children():
            groupsTree.delete(item)

        MainMenu.displayGroups(groupsTree)
        #close window 
        window.destroy()

    def cancelGroupButton(window):
        #close the window
        window.destroy()

    #Add group to 
    def addGroupFrame(groupsTree):
        addGroupPrompt = tk.Toplevel()

        #create frame for label and buttons
        masterFrame = tk.Frame(addGroupPrompt)
        buttonsFrame = tk.Frame(masterFrame)

        masterFrame.pack()

        #create label 
        entryLabel = tk.Label(masterFrame, text="Enter Group Name: ")

        # create entry
        groupEntry = tk.Entry(masterFrame)

        #create add and cancel buttons
        addButton = tk.Button(buttonsFrame,text="ADD", height=2, width=20, command=lambda:MainMenu.addGroupButton(groupsTree,addGroupPrompt,FileManager.getCurrentUser(),groupEntry.get().strip()))
        cancelButton= tk.Button(buttonsFrame, text= "CANCEL", height=2, width=20,command=lambda:MainMenu.cancelGroupButton(addGroupPrompt))


        #pack 
        entryLabel.pack(pady=5)
        groupEntry.pack(ipadx= 10, ipady=10, pady= 5)


        buttonsFrame.pack(pady=5 )

        cancelButton.pack(side=tk.LEFT)
        addButton.pack(side=tk.LEFT)

    def removeGroupFrame(groupTree):
        removeGroupPrompt = tk.Toplevel()

        # Create frames and pack master for popup
        masterFrame = tk.Frame(removeGroupPrompt)

        masterFrame.pack()

        # Create frame for button
        buttonsFrame = tk.Frame(masterFrame)
        
        #Create label for 'Are you sure?' prompt
        confirmLabel = tk.Label(masterFrame,text="Are you sure you want to delete this group? ", font=("Arial",15))

        #Create buttons 'YES' and 'NO' 

        yesButton =  tk.Button(buttonsFrame,text="YES", padx=5, height=2, width=20, command=lambda:MainMenu.removeGroupFromManager(removeGroupPrompt,groupTree))
        noButton  =  tk.Button(buttonsFrame, text="NO", padx= 5, height=2, width=20, command=lambda:MainMenu.cancelGroupButton(removeGroupPrompt))


        # Pack contents 

        confirmLabel.pack()
        buttonsFrame.pack(pady=5)

        noButton.pack(side=tk.LEFT)
        yesButton.pack(side=tk.LEFT)
    
        

# *****************************BROWSE FILES *************************************************************************
    #tkinter window that lets user browse files
    def browseFiles(groupWindow,group):
        
        groupWindow.destroy()

        share_group = group.strip()

        filename = filedialog.askopenfilename(initialdir="/",
                                              title="Select a File",
                                              filetypes=(
                                                  ("Text files", "*.txt"),
                                                  ("all files", "*")))
        
        if filename:
            
            user = FileManager.getCurrentUser()
            #append file information to users

            FileManager.encryptFile(user,filename,share_group)

            
        #return filename

    #upload file and update lsitbox
    def browseFilesMyFiles(listbox):
        filename = filedialog.askopenfilename(initialdir="/",
                                              title="Select a File",
                                              filetypes=(
                                                  ("Text files", "*.txt"),
                                                  ("all files", "*")))
        
      
        if filename:
        
            listbox.insert("end",filename)

            print(FileManager.getCurrentUser())

            FileManager.encryptFile(FileManager.getCurrentUser(),filename,'self')
        
        else:
            return False

    #for select group function

    def show(label,clicked):
        label.config(text = clicked.get())
    #creates a popup drop down menu for groups
    def selectGroup():

        #create toplevel window
        groupWindow = tk.Toplevel()
        groupWindow.geometry("200x200")


        #get user from group 
        user = FileManager.getCurrentUser()

        #array to hold group options
        groupOptions = []

        #get path of masterfile csv

        path = f"SFSA_ACC/{user}/Groups/masterfile.csv"

        #for loop to loop through master csv and display options
        with open(path) as f:
            reader = csv.DictReader(f, delimiter=',')
            for row in reader:
                name = row['name']
                groupOptions.append(name)
                
            f.close()
        #data type of menu text
        clicked = tk.StringVar()

        if groupOptions:
            clicked.set(groupOptions[0])
        else:
            clicked = "None"

        selectGroupLabel = tk.Label(groupWindow, text = " ")
    
        #create drop down menu
        dropDownMenu = tk.OptionMenu(groupWindow,clicked, *groupOptions, command=lambda x=None: MainMenu.show(selectGroupLabel,clicked))

        uploadBtn = tk.Button(groupWindow, text="SHARE", command=lambda:MainMenu.browseFiles(groupWindow,selectGroupLabel.cget('text')))
        #creat label

        selectGroupLabel.pack()
        dropDownMenu.pack()
        uploadBtn.pack()


# *****************************PARENT FRAME *************************************************************************
    def __init__(self,parent,controller):

        tk.Frame.__init__(self,parent)


         #set the weights of the columns and rows 
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=3)
        self.grid_columnconfigure(2, weight=1)

        self.grid_rowconfigure(0,weight=1)
        self.grid_rowconfigure(1,weight=1)
        self.grid_rowconfigure(2,weight=1)
        self.grid_rowconfigure(3,weight=1)
        

        # *********** MY FILES ***************************************

        #frame for myfiles widgets
        myFilesframe = tk.Frame(self, highlightbackground="#20bebe",highlightthickness=2)
        myFilesframe.grid(column=0, row=1)

        #frame for myfiles buttons
        myFilesButtons = tk.Frame(self)
        myFilesButtons.grid(column=0,row=3)

        #frame for myFiles ListBox

        myFiles_lbf = tk.Frame(self)
        myFiles_lbf.grid(column=0,row=2)

        #listbox
        myFiles_lb = tk.Listbox(myFiles_lbf, width=50, height=20)
        
        #scroll bar for listbox
        myfiles_scroll = tk.Scrollbar(myFiles_lbf)

        #Label for myFiles
        myFilesLabel = tk.Label(myFilesframe, text="My Files",font=("Arial",15))

        #Image for myFiles
        myFilesImage = Image.open("my_files1.png")
        myFiles_tk = ImageTk.PhotoImage(myFilesImage)
        myFilesImageLabel = tk.Label(myFilesframe,image=myFiles_tk)
        myFilesImageLabel.image = myFiles_tk


        #Buttons For myfiles
        #myFilesUpload_btn =   tk.Button(myFilesButtons,text="UPLOAD", bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.browseFiles)
        myFilesUpload_btn =   tk.Button(myFilesButtons,text="UPLOAD", bg="#20bebe", fg="white", anchor='center', height=2, width=20, command= lambda : MainMenu.browseFilesMyFiles(myFiles_lb))

        myFilesDownload_btn = tk.Button(myFilesButtons,text="DOWNLOAD",bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.myFilesScreen )


        # Pack myFiles

        myFiles_lb.pack(side=tk.LEFT, fill=tk.BOTH)
        myfiles_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        myFilesLabel.pack(pady=20,padx=20)
        myFilesImageLabel.pack(pady=20,padx=20)

        myFilesUpload_btn.pack(ipady=10,pady=20)
        myFilesDownload_btn.pack(ipady=10)


        # *********** SHARED FILES ***************************************

        #frame for sharedFiles widgets
        sharedFilesFrame = tk.Frame(self,highlightbackground="#20bebe",highlightthickness=2)
        sharedFilesFrame.grid(column=1, row=1)

        #frame for sharedFiles buttons
        sharedFilesButtons = tk.Frame(self)
        sharedFilesButtons.grid(column=1,row=3)

        #frame for shared ListBox

        sharedFiles_lbf = tk.Frame(self)
        sharedFiles_lbf.grid(column=1,row=2)

        #listbox
        sharedFiles_lb = tk.Listbox(sharedFiles_lbf, width=50, height=20)
        
        #scroll bar for listbox
        sharedfiles_scroll = tk.Scrollbar(sharedFiles_lbf)

        #Label for sharedFiles
        sharedFilesLabel = tk.Label(sharedFilesFrame, text="Shared Files",font=("Arial",15))

        #Image for sharedFiles
        sharedFilesImage = Image.open("shared_files1.png")
        sharedFiles_tk = ImageTk.PhotoImage(sharedFilesImage)
        sharedFilesImageLabel = tk.Label(sharedFilesFrame,image=sharedFiles_tk)
        sharedFilesImageLabel.image = sharedFiles_tk


        #Buttons For sharedFiles
        sharedFilesView_btn =   tk.Button(sharedFilesButtons,text="UPLOAD", bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.selectGroup)
        sharedFilesDownload_btn = tk.Button(sharedFilesButtons,text="DOWNLOAD",bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.sharedFilesScreen)
       
        #Pack Shared Files

        sharedFiles_lb.pack(side=tk.LEFT, fill=tk.BOTH)
        sharedfiles_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        sharedFilesLabel.pack(pady=20,padx=20)
        sharedFilesImageLabel.pack(pady=20,padx=20)

        sharedFilesView_btn.pack(ipady=10,pady=20)
        sharedFilesDownload_btn.pack(ipady=10)



        # *********** GROUPS  ***************************************

        #frame for groups
        groupFrame = tk.Frame(self,highlightbackground="#20bebe",highlightthickness=2)
        groupFrame.grid(column=2, row=1)

        #frame for groups buttons
        groupsButtons = tk.Frame(self)
        groupsButtons.grid(column=2,row=3)

        #frame for shared ListBox

        groups_lbf = tk.Frame(self)
        groups_lbf.grid(column=2,row=2)

        #listbox
        groups_lb = tk.Listbox(groups_lbf, width=50, height=20)
        
        #scroll bar for listbox
        groups_scroll = tk.Scrollbar(groups_lbf)

        #Label for groups
        groupsLabel = tk.Label(groupFrame, text="Groups",font=("Arial",15))

        #Image for groups
        groupImage = Image.open("group_icon.png")
        group_tk = ImageTk.PhotoImage(groupImage)
        groupImageLabel = tk.Label(groupFrame,image=group_tk)
        groupImageLabel.image = group_tk

      
        
        #   Buttons For Groups
        groupsView_btn =   tk.Button(groupsButtons,text="VIEW", bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.GroupsScreen)
        groupsCreate_btn = tk.Button(groupsButtons,text="CREATE",bg="#20bebe", fg="white", anchor='center', height=2, width=20, command=MainMenu.manageGroupsScreen)


        #Pack groups
        groups_lb.pack(side=tk.LEFT, fill=tk.BOTH)
        groups_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        groupsLabel.pack(pady=20,padx=20)       
        groupImageLabel.pack(pady=20,padx=20)

        groupsView_btn.pack(ipady=10,pady=20)
        groupsCreate_btn.pack(ipady=10)




#class to run tkinter mainloop in a thread so we can send info to 
# client service
#class App(threading.Thread):
#    def __init__(self):
#        threading.Thread.__init__(self)
#        self.start()

#    def callback(self):
#        self.root.quit()

#    def run(self):
#        self.app = SFSA()
#        self.app.mainloop()

#class to run our client side of the app on a thread
#class Client(threading.Thread):
#    def __init__(self):
#        threading.Thread.__init__(self)
#        self.start()
#    def callback(self):
#        self.quit()

#    def run(self):
#        SFSA_Client.main()
        

#Run our app

#app = App()
#client = Client()
