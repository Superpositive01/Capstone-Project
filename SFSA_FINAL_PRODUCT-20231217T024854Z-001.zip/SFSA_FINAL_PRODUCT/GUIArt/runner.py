import subprocess
import sys

pid1 = subprocess.Popen([sys.executable, "SFSA.py"]) 
pid2 = subprocess.Popen([sys.executable, "SFSA_Client.py"]) 