
#create seperate tkinter instances for warning boxes

from stat import SF_APPEND
import tkinter as tk
import SFSA
def accountMessages(message):
        if message == "AVAILABLE":
           tk.messagebox.showinfo(message="Account Created Successfully")
        elif message  == "TAKEN":
            tk.messagebox.showerror(message="Username TAKEN Please enter anonther")
def badLogin():
            tk.messagebox.showerror(message="BAD LOGIN")
def switchScreen(message):
            if message == "GOOD_LOGIN":
               SFSA.LoginScreen.switchFrame = True
            