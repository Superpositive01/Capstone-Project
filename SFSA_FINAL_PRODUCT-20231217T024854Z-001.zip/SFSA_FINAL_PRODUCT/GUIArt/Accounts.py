# This file contains all the code to create a Account Filesystem
# Preston Robbins
# JAN 13 2022

from dataclasses import dataclass
from typing import List
import string


# data class for account creation
@dataclass
class Account:
        username: string
        password: string
        #privateKey: string
        #publicKey: string
        #keyRing : list
        #fileHashes: list
        #fileName: list

        #initalization function
        def __init__(self,name: str, password: str):
                self.name = name
                self.password = password
                    
        # set the username
        def setUserName(self,name: str):
                self.username = name

        # get the user name
        def getUserName(self) -> string:
                return self.username
        
        #set the password
        def setPassword(self,pw : str):
                self.password = pw
        
        #get the password
        def getPassword(self) -> string:
                return self.password



