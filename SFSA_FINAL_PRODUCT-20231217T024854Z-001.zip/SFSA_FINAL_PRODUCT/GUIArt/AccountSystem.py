# AccountSystem.py
# Preston Robbins
# This file contaisn functions that deal with account management

import re
from unittest import result 


# Check if AccountName meets requirments
# Name no more than 25 characters
# Contains no special characters

def checkNameRequirments(accountName):
    #regular expression that checks for uppercase lowercase and numbers
    requirement = re.compile('^[A-Za-z0-9]+$')

    #result will return a match object if valid
    #if not then it will return None 
    results = re.match(requirement,accountName)

    #check length requirment
    if(len(accountName) > 25):
        return False

    #check if no match is found
    elif(results == None):
        return False

    else:
        return True

# Check if Password meets requirments
# Password must be at least 8 characters
# Contains 1 special character
# Contaisn 1 Uppercase character
# No Spaces

def checkPasswordRequirement(password):
    
    #regular expression that checks for special character
    #checks for a number
    #checks for a uppercase character
    requirment = re.compile("^(?=.*[\d])(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$!])[\w\d@#$]{6,12}$")
    results = re.match(requirment,password)

    #check length requirment
    if(len(password) > 30):
        return False

    elif(results == None):
        return False
    
    else:
        return True

# Check if ConfirmBoxes are equal to each other

def confirmEqual(string1,string2):

    if(string1 == string2):
        return True
    
    else:
        return False

# get entry function

def getEntry(string1):
    return string1

# Confirm that userName is available

# Send request to server

# Get result of request from server

