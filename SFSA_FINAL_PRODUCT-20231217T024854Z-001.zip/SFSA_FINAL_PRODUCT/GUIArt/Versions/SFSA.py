# Multi-frame tkinter application v2.3
import tkinter as tk
from tkinter.constants import SEL_FIRST
from PIL import Image, ImageTk

class SFSA(tk.Tk):
   



    #initialization function for frames
    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self,*args,**kwargs)
        
        # set teh container to tk.Frame
        container = tk.Frame(self)

        #pack
        container.pack(side="top",fill="both",expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0,weight=1)

        #dictonary of frames
        self.frames = {}

        # set frame to start page upon initalization 
        frame = WelcomeScreen(container,self)

        # set current frame to StartPage
        self.frames[WelcomeScreen] = frame

        # 
        frame.grid(row=0, column=0, sticky="nsew")
        
        # show the frame
        self.show_frame(WelcomeScreen)
        self.bind('<Button-1>', SFSA.display_coordinates)

    #print x y coordiantes upon button press
    def display_coordinates(event):
            print(f'x={event.x} y={event.y}')

    # function to show frame
    def show_frame(self,cont):
        frame = self.frames[cont]
        frame.tkraise()
    

class WelcomeScreen(tk.Frame):
        def __init__(self,parent,controller):

            tk.Frame.__init__(self,parent)

            # set the window size for the screen
            canvas = tk.Canvas(self, width=1850, height=554)
            
            # use the 3 column grid
            canvas.grid(columnspan=3)
            
          
            #open image using PIL library
            logo = Image.open('loginscreen.png')

            #convert image to a usable tkinter library 
            logo = ImageTk.PhotoImage(logo)

            # Set image in canvas
            canvas.create_image(0,0, image=logo, anchor="nw")

            canvas.create_image = logo


            #add a tkinter label widgit
            #logo_label = tk.Label(canvas,image=logo)

            # load image 
            #logo_label.image = logo

            #place logo inside window using grid

            #logo_label.grid(column=1,row=0)

            # Login Button 
            login_btn = tk.Button(self, text="LOGIN", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17)
            
            login_btn_window = canvas.create_window(947,403, anchor="sw", window=login_btn)
            #login_btn.grid(column= 2, row = 0)

            # Create Account button 
            #create_acc_btn = tk.Button(canvas, text="Create Account", anchor = 'w', font="Raleway")

            #create_acc_btn.grid(column=1, row=2)
            create_acc_btn = tk.Button(self, text="CREATE ACCOUNT", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17)
            
            create_acc_window = canvas.create_window(947,508, anchor="sw", window=create_acc_btn)
       
class LoginScreen(tk.Frame):
 def __init__(self,parent,controller):

            tk.Frame.__init__(self,parent)

            # set the window size for the screen
            canvas = tk.Canvas(self, width=1850, height=554)
            
            # use the 3 column grid
            canvas.grid(columnspan=3)
            
          
            #open image using PIL library
            logo = Image.open('loginscreen.png')

            #convert image to a usable tkinter library 
            logo = ImageTk.PhotoImage(logo)

            # Set image in canvas
            canvas.create_image(0,0, image=logo, anchor="nw")

            canvas.create_image = logo


            #add a tkinter label widgit
            #logo_label = tk.Label(canvas,image=logo)

            # load image 
            #logo_label.image = logo

            #place logo inside window using grid

            #logo_label.grid(column=1,row=0)

            # Login Button 
            login_btn = tk.Button(self, text="LOGIN", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17)
            
            login_btn_window = canvas.create_window(947,403, anchor="sw", window=login_btn)
            #login_btn.grid(column= 2, row = 0)

            # Create Account button 
            #create_acc_btn = tk.Button(canvas, text="Create Account", anchor = 'w', font="Raleway")

            #create_acc_btn.grid(column=1, row=2)
            create_acc_btn = tk.Button(self, text="CREATE ACCOUNT", anchor = 'center' , font="Raleway", bg ="#20bebe", fg="white", height=2, width=17)
            
            create_acc_window = canvas.create_window(947,508, anchor="sw", window=create_acc_btn)
       
class CreateAccountScreen(tk.Frame):
    print()
# run the gui 
app = SFSA()
app.mainloop()