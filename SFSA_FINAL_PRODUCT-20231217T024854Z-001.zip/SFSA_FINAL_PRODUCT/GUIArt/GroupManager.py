# This file is the python file that is responsible for managing groups and interacts with the GUI 
import os
from pathlib import Path
import csv
from datetime import date, datetime
from tokenize import group
import pandas as pd

#create group folder for user

#header for group file 
#header for csv
header = ['name','date','time','host']
#header for csv users to add to group
userheader = ['user','date','time','host']


# data for group csv

data = [None] * 4

#also creates mastergroupfile textfile to keep track of all groups
def createGroupFolder(username):
    #file path to folder
    path = Path(f"SFSA_ACC/{username}/Groups/")
    
    if os.path.exists(path) == False:
        os.mkdir(path)
    else:
        print("GOOD PATH FOR USER")

    #check if mastergroup file is created
    filepath = Path(f"SFSA_ACC/{username}/Groups/masterfile.csv")
    print("FILEPATH GROUPS IS", filepath)
    if filepath.is_file() == False:
        #create the file 
        with open(filepath,'w') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(header)
            csvfile.close()
    

#add to group masterfile
def addToGroupMasterFile(username,groupname):
    path = f"SFSA_ACC/{username}/Groups/masterfile.csv"

    #for date and time 
    today = datetime.now()
    dt_string = today.strftime("%d/%m%Y %H:%M:%S")
    dt_arr = dt_string.split(" ")
    c_date = dt_arr[0]
    c_time = dt_arr[1]
    #the fileds for the file are name, date ,time ,host


    data[0] = groupname
    data[1] = c_date
    data[2] = c_time
    data[3] = username

    #append to csv
    with open(path, 'a') as csvfile:
        #create writer object
        csvwriter = csv.writer(csvfile)

        #write row
        csvwriter.writerow(data)

        csvfile.close()

def removeFromGroupMasterFile(username,name,date,time,host):
    #path to groupfile
    path = f"SFSA_ACC/{host}/Groups/masterfile.csv"

    #convert csv to dataframe
    df = pd.read_csv(path)

    #locate row with groupname
    #groupValueDF = df.loc[  ( (df['name'] != name) & (df['date'] != date) & (df['time'] != time) &  (df['host'] != host) )]
    groupValueDF = df.loc[  ( (df['name'] != name))]

    print("GROUP DATA FRAME IS ", groupValueDF)

    #convert df to modified csv
    groupValueDF.to_csv(path,index=False)
    #remove file from user directory 
    removeGroup(host,name)

#function that adds groups in the format groups.txt

def addGroup(username,groupName):

    path = f"SFSA_ACC/{username}/Groups/"
    # go to file path form username

    group_text = groupName.strip()+".csv"
    
    group_file = Path(path+group_text)
    
    #create group name if it is not a duplicate

    if group_file.is_file() == False:
        #create group text file
        with open(group_file,'w') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(userheader)
            csvfile.close()

    #call to append group to group master file to make it visable on gui 
    addToGroupMasterFile(username,groupName)

def removeGroup(username,groupName):
    #Path to CSV
    path = f"SFSA_ACC/{username}/Groups/"

    #append .csv to groupName
    filename = Path(f"{path}+{groupName}.csv")

    #delete the file if it exsits
    if filename.is_file() == True:
        os.remove(filename)

def addUserToGroupFile(username,group,user):
    #path to group csv
    path = f"SFSA_ACC/{username}/Groups/{group}.csv"

    #for date and time 
    today = datetime.now()
    dt_string = today.strftime("%d/%m%Y %H:%M:%S")
    dt_arr = dt_string.split(" ")
    c_date = dt_arr[0]
    c_time = dt_arr[1]
    #the fileds for the file are name, date ,time ,host


    data[0] = user
    data[1] = c_date
    data[2] = c_time
    data[3] = username

    #append row to 

    #append to csv
    with open(path, 'a') as csvfile:
        #create writer object
        csvwriter = csv.writer(csvfile)

        #write row
        csvwriter.writerow(data)

        csvfile.close()

def removeUserFromGroup(username,group,user):
    #path to groupfile
    path = f"SFSA_ACC/{username}/Groups/{group}.csv"

    #convert csv to dataframe
    df = pd.read_csv(path)

    #locate row with groupname
    groupValueDF = df.loc[  ( (df['user'] != user))]

   #print("GROUP DATA FRAME IS ", groupValueDF)

    #convert df to modified csv
    groupValueDF.to_csv(path,index=False)

#def appendToMasterFile(name):
    #get path to masterfile
#    path = f"SFSA_ACC/{name}/Grops/masterfile.csv"
