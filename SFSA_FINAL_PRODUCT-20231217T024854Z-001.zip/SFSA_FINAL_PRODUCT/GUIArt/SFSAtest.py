# Multi-frame tkinter application v2.3
import tkinter as tk
from PIL import Image, ImageTk

class SFSA(tk.Tk):
    #initialization function for frames
    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self,*args,**kwargs)
        
        # set teh container to tk.Frame
        container = tk.Frame(self)

        #pack
        container.pack(side="top",fill="both",expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0,weight=1)

        #dictonary of frames
        self.frames = {}

        # set frame to start page upon initalization 
        frame = StartPage(container,self)

        # set current frame to StartPage
        self.frames[StartPage] = frame

        # 
        frame.grid(row=0, column=0, sticky="nsew")
        
        # show the frame
        self.show_frame(StartPage)
    
    # function to show frame
    def show_frame(self,cont):
        frame = self.frames[cont]
        frame.tkraise()

def qf(param):
    print(param)

class StartPage(tk.Frame):
        def __init__(self,parent,controller):
            tk.Frame.__init__(self,parent)
            label = tk.Label(self,text="Start Page")
            label.pack(padx= 10, pady=10)

            button1 = tk.Button(self, text="Visit Page 1 ", 
                           command=lambda: qf("see this worked") )
            button1.pack()
# run the gui 
app = SFSA()
app.mainloop()