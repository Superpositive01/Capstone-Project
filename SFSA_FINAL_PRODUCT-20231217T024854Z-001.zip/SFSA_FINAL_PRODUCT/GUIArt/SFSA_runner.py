
import threading
import SFSA
import SFSA_Client
import ipfsApi

#class to run tkinter mainloop in a thread so we can send info to 
# client service
class App(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.start()

    def callback(self):
        self.root.quit()

    def run(self):
        self.app = SFSA.SFSA()
        self.app.mainloop()

#class to run our client side of the app on a thread
class Client(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.start()
    def callback(self):
        self.quit()

    def run(self):
        SFSA_Client.main()
        

#Run our app

app = App()
client = Client()
