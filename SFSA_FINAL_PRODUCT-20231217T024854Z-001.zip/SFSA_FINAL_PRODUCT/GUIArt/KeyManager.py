#file to send keys to the server

from rsa import PrivateKey


def sendKeys(username):
    path = "SFSA_ACC/{username}/"
    
    #open private key

    #open public key

    #open symetric key


