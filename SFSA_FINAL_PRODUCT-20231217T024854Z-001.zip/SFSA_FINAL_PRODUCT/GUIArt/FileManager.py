# This program contains functions that will input 
# data about a file that is shared between users of the program
# Each file will be named after the user and contains the following
# 1. FileName Shared
# 2. FileHash after encrpytion
# This is going to be in a csv file
# This will also create public/private keys for file sharing

from cmath import pi
from pathlib import Path
import csv
import shutil
from tabnanny import check
from tokenize import group
import rsa
from cryptography.fernet import Fernet
import os 
#import ipfsApi
#import ipfsApi
import ipfshttpclient
import time
from datetime import date, datetime
import SFSA_Client
import pickle
import codecs
import pandas as pd

#api for ipfs
api = ipfshttpclient.connect('/ip4/10.0.2.15/tcp/5001')


#variable for current user filename and hash

u_name = ""
l_filename=""
l_hash=""

#path
path="SFSA_ACC/"

#add group header when we implement groups so we can use pandas dataframe regular expressions to filter out who can access things
# The only thing the panel buttons will change is the flag
# also send keys to decrypt data across the wire

#header for csv
header = ['name','filename','hash','date','time','group']
#data to input in csv has to be in the following format
# user, filename, hash, date , time
#initalize to nothign when starting 

data = [None] * 6

# set current filename
def setFilename(filename):
    global l_filename
    l_filename = filename

# get current filenmame
def getFileName():
    return l_filename

# set current hash
def setCurrentHash(hash):
    global l_hash
    l_hash = hash

# get current hash
def getHash():
    return l_hash

#After login store the current uer name in u_name
def setCurrentUser(name):
    global u_name
    u_name = name
#Get current user

def getCurrentUser():
    return u_name   
#check for file in local directory that is u_name.txt
#do this on login
def checkForFile(name):
    filename = name.strip()
    filepath = f"SFSA_ACC/{filename}"
    filepath = Path(filepath)
    print(filepath)
    print(filepath.is_file())
    return filepath.is_file()
       

#create the file for login if it does not exsist
def createUserNameFile(name):
    filename = name +".csv"
    filepath = Path(path+filename)
    if checkForFile(filename) == False:
        with open(filepath, 'w', encoding='UTF8') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(header)

            csvfile.close()

#place keys


def placeKeys(username,keyArr):
    privateKey = keyArr[0]
    publicKey = keyArr[1]
    symetricKey = keyArr[2]


    pKey = username + "private" + ".key"
    puKey  = username+ "public"  + ".key"
    symeKey = username + "symetric" + ".key"

    keyPath = f"SFSA_ACC/{username}/"

   


    #create key files
    with open(keyPath + f"{pKey}",'w') as f:
        f.write(privateKey)
        f.close()

    with open(keyPath + f"{puKey}",'w') as f:
        f.write(publicKey)
        f.close()
    with open(keyPath + f"{symeKey}",'w') as f:
        f.write(symetricKey)
        f.close()




#check if keys for user already exsist
def checkKeys(name):
    privateKey = name + "private" + ".key"
    publicKey  = name + "public"  + ".key"
    symetricKey = name + "symetric" + ".key"

    keyPath = f"SFSA_ACC/{name}/"

    privateKeyPath = Path(keyPath+privateKey)
    publicKeyPath = Path(keyPath+publicKey)
    symetricKeyPath = Path(keyPath+symetricKey)

   
   

    if (privateKeyPath.is_file() and publicKeyPath.is_file() and symetricKeyPath.is_file()) == True:
        print("Keys Are GOOD!")
        return True

    else:
        print("Keys FALSE")
        return False


# create symetric key
# create public key
# create private key
def createKeys(name):



    #create account key directory

    
    if checkKeys(name) == False:

        keyPath = f"SFSA_ACC/{name}/"
        keypathos = os.path.join(path,name)

        os.mkdir(keypathos)
        
        encyptedKeyPath = f"SFSA_ACC/{name}/encryptedKeyStore/"

    
        os.makedirs(Path(encyptedKeyPath))
        
        #generate symetric key
        #key = Fernet.generate_key()
        #k = open(keyPath+f'{name}symetric.key','wb')
        #k.write(key)
        #k.close()

        #create the pub and private key
        #(pubkey,privkey) = rsa.newkeys(2048)
        # generate public and private keys
        #pukey = open(keyPath+f'{name}public.key','wb')
        #pukey.write(pubkey.save_pkcs1('PEM'))
        #pukey.close()

        #prkey = open(keyPath+f'{name}private.key','wb')
        #prkey.write(privkey.save_pkcs1('PEM'))
        #prkey.close()
        #print("CREATED KEYS")


# To share files encrpyt with a shared users public key
# To keep files to self encrpyt with current accounts public key

# send encrypted file and encrypted key so a user can decrypt the file 

 #encrypt file

def encryptFile(name,file,group):
    #open symetric key
    keyPath = f"SFSA_ACC/{name}/"
    keystorePath = keyPath + "encryptedKeyStore/"

    skey = open(keyPath + f'{name}symetric.key','rb')
    key = skey.read()
    #create cipher
    cipher = Fernet(key)

    # open file for encrypting 
    myfile = open(file, 'rb')
    myfiledata = myfile.read()
    #encrypt the data

    encrypted_data = cipher.encrypt(myfiledata)
    edata = open(file,'wb')
    edata.write(encrypted_data)
    edata.close()
    time.sleep(10)
    

    print(encrypted_data)

    #upload file to ipfs and save the hash of the file
    addTOIPFSNetwork(file)

    # open public key file
    pkey = open(keyPath + f"{name}public.key",'rb')
    pkdata = pkey.read()

    # load the file 
    pubkey = rsa.PublicKey.load_pkcs1(pkdata)

    # encrypt the symmetric key file with the public key
    encrypted_key = rsa.encrypt(key,pubkey)

    # write encypted symetric key to a file 
    #regular expression to get rid split file on all / 
    ridOfPath = file.split('/')
    ridOfPath = ridOfPath[-1].strip()

    #set the filename
    setFilename(ridOfPath)

    ekey = open(keystorePath + f'{ridOfPath}encrypted.key','wb')
    ekey.write(encrypted_key)
    
    #send encrypted key to server
    ekey_data = encrypted_key

    #pickle message data


    server_message = [name,ekey_data,ridOfPath]

    server_message = pickle.dumps(server_message)

    SFSA_Client.setByteType("UPLOAD_SYM_KEY")

    SFSA_Client.addMessagetoQ(server_message)

    time.sleep(5)

    # add data to csv

    if group == 'self':
        addtoCSV(data,getCurrentUser(),group)

    elif group != 'self':

        #path to group selected
        pathToGroupFile = f"SFSA_ACC/{getCurrentUser()}/Groups/{group}.csv"

            #open csv and send file to master
        with open(pathToGroupFile) as f:
                reader = csv.DictReader(f, delimiter=',')
                for row in reader:
                    name = row['user']
                    date = row['date']
                    u_time = row['time']
                    host = row['host']
                    addtoCSV(data,name,group)
                f.close()
    #print(encrypted_key)

# add file to ipfs network and save file hash to csv
def addTOIPFSNetwork(file):
    # add file to ipfs and return hash
    new_file = api.add(file)
    #get the hash of file to upload to blockchain
    #0 - name 1 - hash 2- size what is reutrned when adding to ipfs

    
    #print(new_file)
    fileHash = new_file['Hash']

    #file_hash = new_file[0]
    #file_hash_value = file_hash.get('Hash')

    setCurrentHash(fileHash)
    print(fileHash)



#function to get hash from csv file
#also downloads file from ipfs and changes the name to original txt
#also calls decrpytion
def getHashFromCSV(name,filename,date,time,group):

    csvPath = f"SFSA_ACC/{name}.csv"

    #convert csv into pandas dataframe
    df = pd.read_csv(csvPath)


    #get rows hash that is equal to name,filename,date,time,group
    hashValueDF = df.loc[ ( (df['name'] == name) & (df['filename'] == filename) & (df['date'] == date) &  (df['time'] == time) & (df['group'] == group) )]
    
    #set current row in data frame to hash
    hash = hashValueDF['hash'].item()
    hash = hash.strip()

    #return hash

    #call get from IPFS based on hash we have
    getFROMIPFSNetwork(hash,name)

    #call file rename also calls decrpytion
    renameFilePulledFromIPFS(hash,name)

    

# get file from IPFS newtork
def getFROMIPFSNetwork(hash,name):
    #use the api to get file from hash
    api.get(hash)
    #move to SFSA_ACC
    shutil.move(hash,f"SFSA_ACC/{name}/{hash}")



def renameFilePulledFromIPFS(hash,name):
    #working directory 
    directory = f"SFSA_ACC/"
    #rename file to what is in the csv
    df = pd.read_csv(directory+f"{name}.csv")
    
    fileNameDF = df.loc[(df['hash'] == hash)]
    
    filename = fileNameDF['filename'].item()
    #rename the file
    os.rename(directory +f"{name}/{hash}",directory +f"{name}/{filename}")

    #decrpyt the file 
    decryptFile(name,filename)

    #get row with hash
# decrypt file
def decryptFile(name,file):
     #open symetric key
    keyPath = f"SFSA_ACC/{name}/"

    #load the priave key to decrypt the public key
    prkey = open(keyPath + f'{name}private.key', 'rb')
    pkey = prkey.read()
    private_key = rsa.PrivateKey.load_pkcs1(pkey)

    #wopen encrypted key 
    e = open(keyPath+"encryptedKeyStore/" + f'{file}encrypted.key', 'rb')
    ekey = e.read()
    dpubkey = rsa.decrypt(ekey,private_key)

    #create cipher
    cipher = Fernet(dpubkey)

    #open encrypted data
    encrypted_data = open(keyPath+f"{file}",'rb')

    edata = encrypted_data.read()
    decrypted_data = cipher.decrypt(edata)


    #print(decrypted_data.decode('unicode_escape'))
    #open file name and write to it
    file = open(keyPath+f"{file}",'w')
    file.write(decrypted_data.decode())
    file.close()


    #open encrypted key
    #tempory place where keys are 

#add if statement if is apart of group or not 
#default group is self

#get Symetric Key

def sendMsgTogetSymetricKey(username,filename):

    SFSA_Client.setByteType("REQUEST_SYMKEY")

    info = [username,filename]

    info = pickle.dumps(info)

    SFSA_Client.addMessagetoQ(info)


# function to add to csv
def addtoCSV(data,name,group):
    #set indexs of data so we can append our row to csv and create a dataframe to check for uploads later
    today = datetime.now()
    dt_string = today.strftime("%d/%m%Y %H:%M:%S")
    dt_arr = dt_string.split(" ")
    c_date = dt_arr[0]
    c_time = dt_arr[1]
    

    #use pickle for data to send over the wire



    if name == getCurrentUser():
        data[0] = name
        data[1] = getFileName()
        data[2] = getHash()
        data[3] = c_date
        data[4]  = c_time
        data[5]  = group
        message = pickle.dumps(data)

        print("TYPE of message CSV",type(message) )

        SFSA_Client.setByteType("APPEND_USER_DOWNLOAD")


        #send the message add file user ADDFLU with data attachted and send data array to server
        SFSA_Client.addMessagetoQ(message)

    elif name != getCurrentUser():
        #print("TYPE of message CSV",type(message) )

        #append original user to data
        nameToSplit = name + " " + getCurrentUser()
        data[0] = nameToSplit
        data[1] = getFileName()
        data[2] = getHash()
        data[3] = c_date
        data[4]  = c_time
        data[5]  = group
        
        message = pickle.dumps(data)

        SFSA_Client.setByteType("APPEND_USER_DOWNLOAD")

        #send the message add file user ADDFLU with data attachted and send data array to server
        SFSA_Client.addMessagetoQ(message)

    # send data over the wire to server to append to master user file

    #write to csv file
    #filename = name +".csv"
    #filepath = Path(path+filename)
    
    #with open(filepath, 'a') as csvfile:
        #create writer object
    #    csvwriter = csv.writer(csvfile)

        #write row
    #    csvwriter.writerow(data)

    #    csvfile.close()


#function to make current user csv a pandas dataframe for querying

#read from csv to update gui

